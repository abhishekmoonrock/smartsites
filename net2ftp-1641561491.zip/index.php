<!DOCTYPE html>
 <html lang="en">
  <head>
<meta name="surfe.pro" content="ad2957989d5262cf17797d549486d736">
<!-- meloads-->
<meta name="maValidation" content="be9aefe12072e0f70004a68598baebd3" />
<!-- meloads-->
<meta name="google-site-verification" content="vUbBS4afmpaIjClZyaL5maSBJB4l3-160yGQ7kdwa7Y" />
<?php include "option.php"; ?>
<style>
    ::-moz-selection { /* Code for Firefox */
 color: white;
  background: darkblue;
}

::selection {
  color: white;
  background: darkblue;
}

/* width */
::-webkit-scrollbar {
  width: 10px;
}

/* Track */
::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px #7fff00; 
  border-radius: 4px;
}

/* Handle */
::-webkit-scrollbar-thumb {
 background-image: linear-gradient(180deg, darkblue 0%, #7fff00 99%);
  border-radius: 4px;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background-image: linear-gradient(180deg,  #7fff00 0%, darkblue 99%);
}
</style>
</head>
<body style=" background: linear-gradient(to right, #00ffb7 0%, #0014ff  100%) no-repeat center center fixed;" >
<div class="well" align="center">
<p>
<span>
<div class="ui large buttons" id="glowsu">
  <a href="https://helpfree.orgfree.com/web" style="color: black;"><button class="ui red button">Desktop View</button></a>
  <div class="or"></div>
  <a href="https://helpfree.orgfree.com/web" style="color: black;"><button class="ui green button">Mobile View</button></a>
</div>
</span>
</p>
<div align="center">
  <iframe style="border-style: none;" src="https://helpfree.orgfree.com/web" width="1390px" height="10000px"></iframe>
</div>
</div>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-129679257-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-129679257-1');
</script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5e43fae9298c395d1ce78e9b/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
<script id='llscript13223' src='https://pjs.leadsleap.net/js.js?c=13223&u=cashmoon1'></script>
</body>
</html>
